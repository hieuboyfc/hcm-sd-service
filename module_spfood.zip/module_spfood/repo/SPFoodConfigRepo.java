package vn.ngs.nspace.ticket.module_spfood.repo;

import com.xdp.lib.repo.BaseRepo;
import org.springframework.stereotype.Repository;
import vn.ngs.nspace.ticket.module_spfood.entity.SPFoodConfig;

import java.util.List;

@Repository
public interface SPFoodConfigRepo extends BaseRepo<SPFoodConfig, Long> {

    List<SPFoodConfig> findAllByCompanyIdAndStatus(Long cid, Integer status);

}
