package vn.ngs.nspace.ticket.module_spfood.service;

public interface EmailService {

    void sendMail(String email);

}
