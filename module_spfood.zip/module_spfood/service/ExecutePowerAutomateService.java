package vn.ngs.nspace.ticket.module_spfood.service;

import org.springframework.web.multipart.MultipartFile;
import vn.ngs.nspace.ticket.module_spfood.dto.SPFoodConfigDTO;
import vn.ngs.nspace.ticket.module_spfood.dto.SPFoodTicketDTO;
import vn.ngs.nspace.ticket.module_spfood.response.FileResponse;

public interface ExecutePowerAutomateService {

    Boolean setupSoftware(SPFoodConfigDTO configDTO, SPFoodTicketDTO ticketDTO);

    Boolean createOrUpdate(SPFoodConfigDTO configDTO, SPFoodTicketDTO ticketDTO);

    Boolean delete(SPFoodConfigDTO configDTO, Long id);

    FileResponse getDataFromFile(SPFoodConfigDTO configDTO, MultipartFile file);

}
