package vn.ngs.nspace.ticket.module_spfood.service;

import vn.ngs.nspace.ticket.module_spfood.dto.SPFoodConfigDTO;

import java.util.List;

public interface SPFoodConfigService {

    List<SPFoodConfigDTO> initData(Long cid, String uid);

}
