package vn.ngs.nspace.ticket.module_spfood.service.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import vn.ngs.nspace.ticket.module_spfood.dto.SPFoodConfigDTO;
import vn.ngs.nspace.ticket.module_spfood.entity.SPFoodConfig;
import vn.ngs.nspace.ticket.module_spfood.repo.SPFoodConfigRepo;
import vn.ngs.nspace.ticket.module_spfood.service.SPFoodConfigService;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class SPFoodConfigServiceImpl implements SPFoodConfigService {

    private final SPFoodConfigRepo repo;

    @Override
    public List<SPFoodConfigDTO> initData(Long cid, String uid) {
        List<SPFoodConfig> listData = repo.findAllByCompanyIdAndStatus(cid, 1);
        if (!listData.isEmpty()) {
            return SPFoodConfig.toDTOs(listData);
        }
        return new ArrayList<>();
    }

}
